<?php
$_GET['archive'] = 'author';
require_once 'blog.php';