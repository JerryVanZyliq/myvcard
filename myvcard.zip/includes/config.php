<?php
$config['db']['host'] = 'localhost';
$config['db']['name'] = 'webgurus_myprofile';
$config['db']['user'] = 'webgurus_bossman';
$config['db']['pass'] = 'IAmThatIAm';
$config['db']['pre'] = 'vc_';
$config['db']['port'] = '';

$config['version'] = '1.4';
$config['installed'] = '1';
?>